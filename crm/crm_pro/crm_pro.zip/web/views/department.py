# -*- coding:utf-8 -*-
# @Author : 'LZ'
# @Time : 2019/12/8 14:02
from .base import PermissionHandler


class DepartmentHandler(PermissionHandler):
	display_list = ['title']
